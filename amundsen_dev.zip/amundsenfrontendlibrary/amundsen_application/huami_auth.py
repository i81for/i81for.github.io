import requests,logging

from typing import Dict, Optional
from flask import Flask,request
from amundsen_application.config import LocalConfig
from amundsen_application.models.user import load_user, User

LOGGER = logging.getLogger(__name__)

def check_token(req:request) -> bool:
    huami_auth_token = req.headers.get('huami_auth_token')
    logging.info('huami auth token is {0}'.format(huami_auth_token))
    resopnse = requests.get(url='http://www.baidu.com')
    logging.info('response status code is {0} and msg is {1}'.format(resopnse.status_code,resopnse.reason))
    return False

def get_access_headers(reg: request) -> Optional[Dict]:
    """
    Function to retrieve and format the Authorization Headers
    that can be passed to various microservices who are expecting that.
    :param oidc: OIDC object having authorization information
    :return: A formatted dictionary containing access token
    as Authorization header.
    """
    try:
        access_token = reg.headers.get('huami_auth_token')
        return {'Authorization': 'Bearer {}'.format(access_token)}
    except Exception:
        return None


def get_auth_user(req:request) -> User:
    """
    Retrieves the user information from oidc token, and then makes
    a dictionary 'UserInfo' from the token information dictionary.
    We need to convert it to a class in order to use the information
    in the rest of the Amundsen application.
    :param app: The instance of the current app.
    :return: A class UserInfo (Note, there isn't a UserInfo class, so we use Any)
    """
    from flask import g
    huami_auth_token = request.headers.get('huami_auth_token')
    user_info = load_user(g.oidc_id_token)
    return user_info


class HuamiAuthConfig(LocalConfig):
    AUTH_USER_METHOD = get_auth_user
    REQUEST_HEADERS_METHOD = get_access_headers


# Copyright Contributors to the Amundsen project.
# SPDX-License-Identifier: Apache-2.0

import logging

from typing import Dict
from http import HTTPStatus

from flask import Response, jsonify, make_response
from flask import current_app as app
from flask.blueprints import Blueprint

from amundsen_application.api.metadata.v0 import USER_ENDPOINT
from amundsen_application.api.utils.request_utils import request_metadata
from amundsen_application.models.user import load_user, dump_user, User


LOGGER = logging.getLogger(__name__)

blueprint = Blueprint('main', __name__, url_prefix='/api')


@blueprint.route('/auth_user_bak', methods=['GET'])
def current_user_bak() -> Response:
    try:
        if app.config['AUTH_USER_METHOD']:
            user = app.config['AUTH_USER_METHOD'](app)
        else:
            raise Exception('AUTH_USER_METHOD is not configured')

        # 此处因为公司没有统一的oidc服务，所以此处需要修改
        url = '{0}{1}/{2}'.format(app.config['METADATASERVICE_BASE'], USER_ENDPOINT, user.user_id)

        response = request_metadata(url=url)
        status_code = response.status_code
        if status_code == HTTPStatus.OK:
            message = 'Success'
        else:
            message = 'Encountered error: failed to fetch user with user_id: {0}'.format(user.user_id)
            logging.error(message)
        payload = {
            'msg': message,
            'user': dump_user(load_user(response.json()))
        }
        return make_response(jsonify(payload), status_code)
    except Exception as e:
        message = 'Encountered exception: ' + str(e)
        logging.exception(message)
        payload = jsonify({'msg': message})
        return make_response(payload, HTTPStatus.INTERNAL_SERVER_ERROR)

# 此处因为公司没有统一的oidc服务，此处操作主要是mock假用户
@blueprint.route('/auth_user', methods=['GET'])
def current_user() -> Response:
    try:
        if app.config['AUTH_USER_METHOD']:
            user = app.config['AUTH_USER_METHOD'](app)
        else:
            raise Exception('AUTH_USER_METHOD is not configured')

        payload = {
            'msg': 'success',
            'user': dump_user(load_user(user_to_dict(user)))
        }
        return make_response(jsonify(payload), HTTPStatus.OK)
    except Exception as e:
        message = 'Encountered exception: ' + str(e)
        logging.exception(message)
        payload = jsonify({'msg': message})
        return make_response(payload, HTTPStatus.INTERNAL_SERVER_ERROR)

#暂时没有接入权限系统，将mock的假用户obj转成dict，方法1
def user_to_dict(obj) -> Dict:
    return obj.__dict__

#暂时没有接入权限系统，将mock的假用户obj转成dict，方法2
def user_to_dict_bak(obj) -> Dict:
    return_dict = {}
    for name in dir(obj):
        value = getattr(obj,name)
        if not name.startswith('__') and not callable(value):
            return_dict[name] = value
    return return_dict





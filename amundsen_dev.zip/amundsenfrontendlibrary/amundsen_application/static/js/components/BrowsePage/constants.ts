export const BROWSE_PAGE_DOCUMENT_TITLE = 'Browse - Amundsen';

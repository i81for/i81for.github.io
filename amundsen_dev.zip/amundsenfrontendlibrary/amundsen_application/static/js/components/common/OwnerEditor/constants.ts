export const DEFAULT_ERROR_TEXT =
  'There was a problem with the request, please reload the page.';
export const USERID_LABEL = 'email address';
export const ADD_ITEM = 'Add';
export const ADD_OWNER = 'Add Owner';
export const DELETE_ITEM = 'Delete Item';
export const NO_OWNER_TEXT = 'No owner';
export const OWNED_BY = 'Owned By';
export const CANCEL_TEXT = 'Cancel';
export const SAVE_TEXT = 'Save';

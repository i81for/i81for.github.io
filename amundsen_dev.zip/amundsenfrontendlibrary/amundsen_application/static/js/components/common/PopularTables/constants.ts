// TODO: Hard-coded text strings should be translatable/customizable
export const POPULAR_TABLES_INFO_TEXT =
  'These are some of the most commonly accessed tables within your organization.';
export const POPULAR_TABLES_LABEL = 'Popular Tables';
export const POPULAR_TABLES_SOURCE_NAME = 'popular_tables';
export const POPULAR_TABLES_PER_PAGE = 4;

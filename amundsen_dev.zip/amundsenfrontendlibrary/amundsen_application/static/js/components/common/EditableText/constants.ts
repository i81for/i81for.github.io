export const REFRESH_MESSAGE =
  'This text is out of date, please refresh the component';
export const REFRESH_BUTTON_TEXT = 'Refresh';
export const UPDATE_BUTTON_TEXT = 'Update';
export const CANCEL_BUTTON_TEXT = 'Cancel';

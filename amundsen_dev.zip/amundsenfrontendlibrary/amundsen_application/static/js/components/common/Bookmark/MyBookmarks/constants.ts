export const BOOKMARK_TITLE = 'My Bookmarks';
export const BOOKMARKS_PER_PAGE = 4;
export const EMPTY_BOOKMARK_MESSAGE =
  "You don't have any bookmarks. Use the star icon to save a bookmark.";
export const MY_BOOKMARKS_SOURCE_NAME = 'bookmarks';

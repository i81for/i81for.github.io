export interface LoggingParams {
  source: string;
  index: number;
}

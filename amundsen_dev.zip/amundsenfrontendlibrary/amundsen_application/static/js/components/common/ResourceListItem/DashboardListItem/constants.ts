export const LAST_RUN_TITLE = 'Last Successful Run';

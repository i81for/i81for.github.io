export const PAGINATION_PAGE_RANGE = 10;

export const DEFAULT_EMPTY_TEXT = 'No resources to display';

export const FOOTER_TEXT_COLLAPSED = 'View all';
export const FOOTER_TEXT_EXPANDED = 'View less';

export const EDIT_TEXT = 'Click to edit';

export const CLOSE = 'Close';

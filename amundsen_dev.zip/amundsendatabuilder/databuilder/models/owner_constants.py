# Copyright Contributors to the Amundsen project.
# SPDX-License-Identifier: Apache-2.0


OWNER_RELATION_TYPE = 'OWNER'
OWNER_OF_OBJECT_RELATION_TYPE = 'OWNER_OF'
